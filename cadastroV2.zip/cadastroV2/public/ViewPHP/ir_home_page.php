<!DOCTYPE html>
<html>
    <head>
          
        <link href="../CSS/CSS_geral.css" rel="stylesheet" type="text/css"/>
        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>ir home page</title>
    </head>
    <body>

    	<a href="http://localhost/cadastrov2/public/index.php">
    		<div class="quadIrHome">
    			
    				<spam class="titulo" >pagina inicial</spam>
    			
    		</div>
    	</a>

    </body>
</html>