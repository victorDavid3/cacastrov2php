<?php
 include('ir_home_page.php');
?>

<!DOCTYPE html>

<html>
    <head>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    	<link rel="stylesheet" type="text/css" href="../CSS/CSS_geral.css">    
        <title>Cadastro</title>
        <meta charset="UTF-8">
    </head>

    <body>

    	

    	<div class="quad">
           
             <form name="forms" action="../../src/ControlerServlet/salvar.php" method="post">
                            
                <label for="nome">Nome</label>
                    <input class="form-control form-control-lg" id="nome" name="nome" type="text" value="" placeholder="Nome" required>
                    <br>

                    <label for="funcao">Função</label>
                    <input class="form-control form-control-lg" id="funcao" name="funcao" type="text" value="" placeholder="Função" required>
                    <br>

                           <input type="submit" class="btn btn-primary" name="verificar" value="Enviar">
             </form>
             
               
    	
    	</body>
</html>