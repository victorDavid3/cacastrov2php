<?php
    include('ir_home_page.php');
?>

<!DOCTYPE html>
<html>
    <head>
          
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
        <link href="../CSS/CSS_geral.css" rel="stylesheet" type="text/css"/>

        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Deletar</title>
    </head>
    <body>

    	<div class="quad">
           
             <form name="forms" action="../../src/ControlerServlet/deletando.php" method="post">
                            
                <label for="ID">ID</label>
                    <input class="form-control form-control-lg" id="ID" name="ID" type="number" value="" placeholder="ID" required> <br/>
                    
                          
                    <input type="submit" class="btn btn-primary" name="verificar" value="Buscar">
                    
             </form>
        </div>


    </body>

</html>