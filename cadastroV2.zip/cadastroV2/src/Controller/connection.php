<?php

$usuario = 'root';
$senha = '';
$database = 'cadastrov2';
$host = 'localhost';

$con = mysqli_connect($host, $usuario, $senha, $database);



    if($con -> error){
        die("Falha ao conectar ao banco de dados: " . $mysql -> error);
    }

    
?>