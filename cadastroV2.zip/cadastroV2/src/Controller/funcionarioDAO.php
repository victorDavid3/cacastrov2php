<?php
class FuncionarioDAO{


	public function	salvarFuncionario ($nome, $funcao){


		include_once('connection.php');

		        
		        
		    $cod_sql= "INSERT INTO funcionarios (nome, funcao) VALUES ('$nome', '$funcao')";


		    $query = mysqli_query ($con, $cod_sql);

		        
		     echo '<script> 

		     alert("Cadastro Realizado");

		     window.location.replace("http://localhost/cadastrov2/public/index.php");

		     </script>';

	}

	public function	listarFuncionario (){

		include_once('connection.php');


        $sql = "SELECT * FROM funcionarios ORDER BY id";

        $result = $con ->query($sql);

        $dados_tabela = null;

        while($funcionario_data = mysqli_fetch_assoc($result)){
        	echo "<tr><td>".$funcionario_data['id'];
        	echo "</td><td>".$funcionario_data['nome'];
        	echo "</td><td>".$funcionario_data['funcao']."</td><tr>";
        }

	}

	public function	buscarFuncionario ($id){

		include_once('connection.php');

        $result = mysqli_query ($con, "select * from funcionarios where id = " . $id);

        $funcionario_data = mysqli_fetch_assoc($result);

        $id = $funcionario_data['id'];
        $nome = $funcionario_data['nome'];
        $funcao = $funcionario_data['funcao'];

        include_once("../model/funcionario.php");
		$fun = new Funcionario();

		$fun ->setId($id);
		$fun ->setNome($nome);
		$fun ->setFuncao($funcao);
		


		return $fun;



	}

	public function	editarFuncionario ($id, $nome, $funcao){

		echo ($id. $nome. $funcao);

		

		include_once('connection.php');

		echo ('$con');

		$cod_sql = "UPDATE funcionarios SET nome = '$nome', funcao = '$funcao' WHERE id = '$id' ";

		$query = mysqli_query ($con, $cod_sql);

       if($query){
       	echo " update realizado";

       	echo '<script> 

       	alert("Edição Realizada");

       	window.location.replace("http://localhost/cadastrov2/public/index.php");

       	</script>';


       } else{
       	echo " erro update";

       	

       	echo '<script> 

       	alert("Erro ao editar");

       	window.location.replace("http://localhost/cadastrov2/public/ViewPHP/editar.php");

       	</script>';
       	

       }

       

	}

	public function	deletarFuncionario ($id){

		include_once('connection.php');

		if($con -> error){
        die("Falha ao conectar ao banco de dados: " . $mysql -> error);
   		 } else{
        
	        // $id = htmlspecialchars($_POST["ID"]);

	        $query = mysqli_query ($con, "DELETE FROM funcionarios WHERE id = " . $id);


		       if($query){
		        echo "Apagado";

		        echo '<script> 

		        alert("Deletado");

		        window.location.replace("http://localhost/cadastrov2/public/index.php");

		        </script>';


			       } else{
			        echo " erro deletar";

			        echo '<script> 

			        alert("Erro ao deletar");

			        window.location.replace("http://localhost/cadastrov2/public/ViewPHP/editar.php");

			        </script>';

			       }


	    }

	}

}
?>