<?php

        $id = htmlspecialchars($_POST["ID"]);
        $nome = htmlspecialchars($_POST["nome"]);
        $funcao = htmlspecialchars($_POST["funcao"]);

        

        include_once('../controller/funcionarioDAO.php');

        $funDAO = new FuncionarioDAO();
    
        $funDAO ->editarFuncionario($id, $nome, $funcao);

?>

