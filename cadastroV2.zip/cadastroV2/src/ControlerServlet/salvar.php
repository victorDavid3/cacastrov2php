<?php

    $nome = htmlspecialchars($_POST["nome"]);
    $funcao = htmlspecialchars($_POST["funcao"]);

    include("../controller/funcionarioDAO.php");

    include("../model/funcionario.php");

    $fun = new Funcionario();

    $funDAO = new FuncionarioDAO();

    $fun ->setNome($nome);

    $fun ->setFuncao($funcao);
    
    $funDAO ->salvarFuncionario($nome, $funcao);

	?>



<!DOCTYPE html>
<html>
    <head>
        
        <link href="../../public/CSS/CSS_geral.css" rel="stylesheet" type="text/css"/>
        
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title>Salvar</title>
    </head>
    <body>

    <div class="quad">
    	<div class="quad_menor">
    		<span>dados foram salvos</span>
    	</div>
    </div>

    </body>
 </html>